export const name = "Textarea";

export const importDocs = `
import { Textarea } from "@/components/ui/textarea"
`;

export const usageDocs = `
<Textarea />
`;
